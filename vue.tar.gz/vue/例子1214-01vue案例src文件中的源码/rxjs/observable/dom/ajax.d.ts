export * from 'rxjs-compat/observable/dom/ajax';
