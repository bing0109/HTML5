export * from 'rxjs-compat/observable/fromIterable';
