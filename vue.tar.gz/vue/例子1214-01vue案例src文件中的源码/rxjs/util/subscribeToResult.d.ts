export * from 'rxjs-compat/util/subscribeToResult';
