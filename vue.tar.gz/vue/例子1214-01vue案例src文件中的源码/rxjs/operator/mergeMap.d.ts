export * from 'rxjs-compat/operator/mergeMap';
