"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
require("rxjs-compat/add/observable/timer");
//# sourceMappingURL=timer.js.map