export * from 'rxjs-compat/operators/pluck';
