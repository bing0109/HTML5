export * from 'rxjs-compat/operators/shareReplay';
