export * from 'rxjs-compat/operators/mergeMap';
