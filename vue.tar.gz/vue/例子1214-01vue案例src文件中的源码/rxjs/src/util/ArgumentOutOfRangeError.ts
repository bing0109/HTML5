export * from 'rxjs-compat/util/ArgumentOutOfRangeError';
