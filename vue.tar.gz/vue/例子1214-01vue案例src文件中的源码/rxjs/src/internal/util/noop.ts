/* tslint:disable:no-empty */
export function noop() { }
