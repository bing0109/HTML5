export * from 'rxjs-compat/operator/concatAll';
