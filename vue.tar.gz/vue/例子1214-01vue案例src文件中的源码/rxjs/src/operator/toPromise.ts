export * from 'rxjs-compat/operator/toPromise';
