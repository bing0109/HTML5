A sample repo for testing the [download-git-repo](https://github.com/flipxfx/download-git-repo) node module.
