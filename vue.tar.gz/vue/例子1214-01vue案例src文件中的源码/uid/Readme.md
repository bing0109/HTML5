
# uid

  generate unique ids of any length

## Installation

### In the browser, using component:

    $ component install matthewmueller/uid

### Using node.js:

    $ npm install uid

## Examples

```js
 uid(10) => "hbswt489ts"
 uid() => "rhvtfnt" Defaults to 7
```

## License

  MIT
