<template>
    <div class="Output_div">
        <textarea></textarea>


    </div>
</template>

<script>
    export default {
        name: "Output_div"
    }
</script>

<style scoped>

</style>
