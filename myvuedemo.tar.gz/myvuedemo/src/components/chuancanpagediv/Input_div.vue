<template>
    <div class="Input_div container">
      <form>
        用户名：<input type="text" placeholder="请输入用户名" />
        <input type="submit" value="提交" >
      </form>
    </div>
</template>

<script>
    export default {
        name: "Input_div"
    }

    alert('divinput')
</script>

<style scoped>
  .Input_div{
      text-align: center;
  }
</style>
