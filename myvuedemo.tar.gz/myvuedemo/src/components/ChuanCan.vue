<template>
    <div>
       <Input_div></Input_div>
       <Output_div></Output_div>
    </div>
</template>

<script>

    import Output_div from './chuancanpagediv/Output_div'
    import Input_div from './chuancanpagediv/Input_div'



    export default {
        name: "ChuanCan",

        components: {
            Output_div,
            Input_div,
        }
    }

</script>

<style scoped>

</style>
