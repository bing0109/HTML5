<template>
    <div id="MyDemoPage">
        <Header></Header>
        <Nav></Nav>
        <DiscountPage></DiscountPage>
        <RecommendPage></RecommendPage>
        <TailPage></TailPage>
    </div>
</template>

<script>
    import Header from './mypage/Header.vue'
    import Nav from './mypage/Nav.vue'
    import DiscountPage from './mypage/DiscountPage.vue'
    import RecommendPage from './mypage/RecommendPage.vue'
    import TailPage from './mypage/TailPage.vue'
    export default {
        name: "MyDemoPage",
        components:{
          Header,
          Nav,
          DiscountPage,
          RecommendPage,
          TailPage,
        }
    }
</script>

<style scoped>

</style>
