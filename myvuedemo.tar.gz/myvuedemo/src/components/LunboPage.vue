<template>
    <div>
        <Title_div></Title_div>
        <Lunbou_div></Lunbou_div>
        <Detail_div></Detail_div>
        <Tail_div></Tail_div>
    </div>

</template>

<script>
    //注册局部组件
    import Title_div from './lunbo/Title_div'
    import Lunbou_div from './lunbo/Lunbou_div'
    import Detail_div from './lunbo/Detail_div'
    import Tail_div from './lunbo/Tail_div'

    export default {
        name: "LunboPage",
        components: {
          Title_div,
          Lunbou_div,
          Detail_div,
          Tail_div
        }
    }
</script>

<style scoped>

</style>
