<template>
    <div>

      <div class="yf_Recommend">
        <h2>推荐商家</h2>
      </div>
      <div class="yf_first">
        <div class="yf_first_img"><img src="../../assets/img/wm-1.gif"/></div>
        <div class="yf_first_right">
          <div class="yf_first_right_top">
            <div class="yf_first_right_top_top">
              <div class="yf_first_right_top_top_img">品牌</div>
              <span>肯德基宅急送(大兴龙湖…</span>
              <div class="yf_first_right_top_top_piao">票</div>
            </div>
            <div class="yf_first_right_top_cen">
              <div class="yf_first_right_top_cen_img">
                <img src="../../assets/img/wm-xing.gif"/>
              </div>
              <span>5.0</span>
              <span>月售50单</span>
            </div>
            <div class="yf_first_right_top_bot">
              <span>0元起送 /</span>
              <span>配送费 ￥9 /</span>
              <span>￥48/人 </span>
            </div>
          </div>
          <div class="yf_first_right_but">
            <div class="yf_first_right_but_top">
              <div class="yf_first_right_but_top_p">减</div>
              <span>满100减40</span>
            </div>
            <div class="yf_first_right_but_top">
              <div class="yf_first_right_but_top_p">新</div>
              <span>新用户立减30元</span>
            </div>
          </div>
        </div>
      </div>
      <div class="yf_first">
        <div class="yf_first_img"><img src="../../assets/img/wm-2.gif"/></div>
        <div class="yf_first_right">
          <div class="yf_first_right_top">
            <div class="yf_first_right_top_top">
              <div class="yf_first_right_top_top_img">品牌</div>
              <span>阿香米线(北京大兴龙…</span>
              <div class="yf_first_right_top_top_piao">票</div>
            </div>
            <div class="yf_first_right_top_cen">
              <div class="yf_first_right_top_cen_img">
                <img src="../../assets/img/wm-xing.gif"/>
              </div>
              <span>5.0</span>
              <span>月售146单</span>
            </div>
            <div class="yf_first_right_top_bot">
              <span>20元起送 /</span>
              <span>配送费 ￥5 /</span>
              <span>￥32/人 </span>
            </div>
          </div>
          <div class="yf_first_right_but">
            <div class="yf_first_right_but_top">
              <div class="yf_first_right_but_top_p">减</div>
              <span>满40减10</span>
            </div>
            <div class="yf_first_right_but_top">
              <div class="yf_first_right_but_top_p">新</div>
              <span>新用户立减30元</span>
            </div>
          </div>
        </div>
      </div>
      <div class="yf_first">
        <div class="yf_first_img"><img src="../../assets/img/wm-3.gif"/></div>
        <div class="yf_first_right">
          <div class="yf_first_right_top">
            <div class="yf_first_right_top_top">
              <div class="yf_first_right_top_top_img">品牌</div>
              <span>北京麦当劳永兴路餐厅</span>
              <div class="yf_first_right_top_top_piao">票</div>
            </div>
            <div class="yf_first_right_top_cen">
              <div class="yf_first_right_top_cen_img">
                <img src="../../assets/img/wm-xing.gif"/>
              </div>
              <span>4.90</span>
              <span>月售525单</span>
            </div>
            <div class="yf_first_right_top_bot">
              <span>20元起送 /</span>
              <span>配送费 ￥5 /</span>
              <span>￥32/人 </span>
            </div>
          </div>
          <div class="yf_first_right_but">
            <div class="yf_first_right_but_top">
              <div class="yf_first_right_but_top_p">减</div>
              <span>满50减6</span>
            </div>
            <div class="yf_first_right_but_top">
              <div class="yf_first_right_but_top_p">新</div>
              <span>新用户立减17.60元</span>
            </div>
          </div>
        </div>
      </div>
      <div class="yf_first">
        <div class="yf_first_img"><img src="../../assets/img/wm-4.gif"/></div>
        <div class="yf_first_right">
          <div class="yf_first_right_top">
            <div class="yf_first_right_top_top">
              <div class="yf_first_right_top_top_img">品牌</div>
              <span>让不让(永兴路店)</span>
              <div class="yf_first_right_top_top_piao">保</div>
            </div>
            <div class="yf_first_right_top_cen">
              <div class="yf_first_right_top_cen_img">
                <img src="../../assets/img/wm-xing.gif"/>
              </div>
              <span>4.8</span>
              <span>月售40单</span>
            </div>
            <div class="yf_first_right_top_bot">
              <span>20元起送 /</span>
              <span>配送费 ￥5 /</span>
              <span>￥0/人 </span>
            </div>
          </div>
          <div class="yf_first_right_but">
            <div class="yf_first_right_but_top">
              <div class="yf_first_right_but_top_p">减</div>
              <span>满100减40</span>
            </div>
            <div class="yf_first_right_but_top">
              <div class="yf_first_right_but_top_p">新</div>
              <span>新用户立减17元</span>
            </div>
          </div>
        </div>
      </div>
      <div class="yf_first">
        <div class="yf_first_img"><img src="../../assets/img/wm-5.gif"/></div>
        <div class="yf_first_right">
          <div class="yf_first_right_top">
            <div class="yf_first_right_top_top">
              <!--<div class="yf_first_right_top_top_img">品牌</div>-->
              <span>那些年板面烧烤</span>
              <div class="yf_first_right_top_top_piao">保</div>
            </div>
            <div class="yf_first_right_top_cen">
              <div class="yf_first_right_top_cen_img">
                <img src="../../assets/img/wm-xing.gif"/>
              </div>
              <span>4.5</span>
              <span>月售217单</span>
            </div>
            <div class="yf_first_right_top_bot">
              <span>20元起送 /</span>
              <span>配送费 ￥5 /</span>
              <span>￥14/人 </span>
            </div>
          </div>
          <div class="yf_first_right_but">
            <div class="yf_first_right_but_top">
              <div class="yf_first_right_but_top_p">减</div>
              <span>满50减7</span>
            </div>
            <div class="yf_first_right_but_top">
              <div class="yf_first_right_but_top_p">新</div>
              <span>新用户立减20元</span>
            </div>
          </div>
        </div>
      </div>
      <div class="yf_first">
        <div class="yf_first_img"><img src="../../assets/img/wm-6.gif"/></div>
        <div class="yf_first_right">
          <div class="yf_first_right_top">
            <div class="yf_first_right_top_top">
              <span>黄焖鸡米饭</span>
              <div class="yf_first_right_top_top_piao">保</div>
            </div>
            <div class="yf_first_right_top_cen">
              <div class="yf_first_right_top_cen_img">
                <img src="../../assets/img/wm-xing.gif"/>
              </div>
              <span>4.7</span>
              <span>月售134单</span>
            </div>
            <div class="yf_first_right_top_bot">
              <span>20元起送 /</span>
              <span>配送费 ￥5 /</span>
              <span>￥14/人 </span>
            </div>
          </div>
          <div class="yf_first_right_but">
            <div class="yf_first_right_but_top">
              <div class="yf_first_right_but_top_p">减</div>
              <span>满25减14</span>
            </div>
            <div class="yf_first_right_but_top">
              <div class="yf_first_right_but_top_p">新</div>
              <span>新用户立减23.0元</span>
            </div>
          </div>
        </div>
      </div>
      <div class="yf_first">
        <div class="yf_first_img"><img src="../../assets/img/wm-7.gif"/></div>
        <div class="yf_first_right">
          <div class="yf_first_right_top">
            <div class="yf_first_right_top_top">
              <div class="yf_first_right_top_top_img">品牌</div>
              <span>送欧巴紫菜包饭</span>
              <div class="yf_first_right_top_top_piao">保</div>
            </div>
            <div class="yf_first_right_top_cen">
              <div class="yf_first_right_top_cen_img">
                <img src="../../assets/img/wm-xing.gif"/>
              </div>
              <span>5.0</span>
              <span>月售413单</span>
            </div>
            <div class="yf_first_right_top_bot">
              <span>20元起送 /</span>
              <span>配送费 ￥5 /</span>
              <span>￥25/人 </span>
            </div>
          </div>
          <div class="yf_first_right_but">
            <div class="yf_first_right_but_top">
              <div class="yf_first_right_but_top_p">减</div>
              <span>满25减5</span>
            </div>
            <div class="yf_first_right_but_top">
              <div class="yf_first_right_but_top_p">新</div>
              <span>新用户立减23.0元</span>
            </div>
          </div>
        </div>
      </div>


    </div>
</template>

<script>
    export default {
        name: "RecommendPage"
    }
</script>

<style scoped>
  div{
    margin:0;padding:0;font-size:0.025rem;font-family:Arial,"微软雅黑";
  }
  body,ul,ol,li,dl,dt,dd,table,p,input,h1,h2,h3,h4,h5,h6{margin:0;padding:0;}
  body{font-size:0.025rem;font-family:Arial,"微软雅黑";}
  a:link,a:visited{text-decoration:none;outline:none;color:#5E5E5E;}
  a img{border:none;}
  ul,li{list-style:none;}
  a:hover{color:#1C468E;}
  input{vertical-align:middle;}
  .left {
    float: left;
    display: inline;
  }

  .right {
    float: right;
    display: inline;
  }

  .clear:after {
    clear: both;
    display: block;
    content: '';
  }

  .clear {
    zoom: 1;
  }

  .a {
    text-decoration: none;
  }

  body {
    font-family: "微软雅黑", "宋体", spanns-serif;
  }

  li {
    list-style: none;
  }

  .swiper-container {
    width: 100%;
    height: 3.5rem;
  }

  .swiper-slide {
    text-align: center;
    font-size: 18px;
    background: #fff;
    display: -webkit-box;
    display: -ms-flexbox;
    display: -webkit-flex;
    display: flex;
    -webkit-box-pack: center;
    -ms-flex-pack: center;
    -webkit-justify-content: center;
    justify-content: center;
    -webkit-box-align: center;
    -ms-flex-align: center;
    -webkit-align-items: center;
    align-items: center;
  }
  .yf_box{width: 100%;}
  .yf_header{width: 100%;height: 7.85rem;background: #2285F4;border: 0.025rem solid #84BBF9;border-left: none;border-right: none;}
  .yf_header_top{width: 11.525rem;height: 1.175rem;float: left;margin-top: 1.05rem;margin-left: 1.925rem;color: #fff;line-height: 1.175rem;text-indent: 1.2/
5m;}
  .yf_header_top_map{width: 5.725rem;height: 0.75rem;float: left;}
  .yf_header_top_map_img{width: 0.8rem;height: 1.15rem;float: left;margin-left: 0.035rem;margin-top: 0.035rem;}
  .yf_header_top_map_img img{width: 100%;height: 100%;float: left;}
  .yf_header_top_right{width: 3.225rem;height: 2.075rem;float: right;margin-top: 1.125rem;margin-right: 1.575rem;}
  .yf_header_top_right_p{width: 3.625rem;height: 2.175rem;color: #fff;}
  .yf_header_top_right_img{width: 1.25rem;height: 2.275rem;float: right;margin-top: -0.955rem;}
  .yf_header_top_right_img img{width: 100%;height: 100%;}
  .yf_header_search{width:100%;height: 2.125rem;float: left;top: 10%;background: #2285F4;}
  .yf_header_search input{color: #9D9FA7;border: none;height: 1.725rem;width: 80%;margin-top: 0.225rem;margin-left: 10%;text-indent: 2.375rem;border-radius: 50px }
  .yf_header_ul{width: 100%;height: 1.035rem;float: left;margin-top: 0.675rem;}
  .yf_header_ul ul li a{width: 20%;height: 1.035rem;float: left;list-style: none;color: #fff;line-height: 1.035rem;text-align: center;text-indent: 0.375rem;}
  .yf_sort{width: 100%;height: 11.75rem;float: left;}
  .yf_sort_div{width: 85%;height: 10.325rem;float: left;margin-top: 10%;margin-left: 6%;}
  .yf_sort_div_top{width: 100%;height: 4.863rem;float: left;margin-left: 4%;}
  .yf_sort_div_top ul li{width: 24%;height: 4.863rem;float: left;}
  .yf_sort_div_top ul li img{width: 85%;height: 3.863rem;text-align: center;margin-left: 0.325rem;}
  .yf_sort_div_top ul li p{text-align: center;}
  .yf_sort_div_bottom{width: 100%;height: 4.863rem;float: left;margin-top: 10%}
  .yf_banner{width: 90%;height: 5.8rem;float: left;background: palegoldenrod;margin-left: 5%;margin-top: 17%;}
  .yf_banner img{width: 100%;height: 100%;}
  .yf_Concessions{height: 9.675rem;float: left;width: 100%;border-top: 0.325rem solid #AEB6B9;}
  .yf_Concessions_top{width: 100%;height: 49.8%;float: left;border-bottom: 0.025rem solid #F9F9F9;}
  .yf_Concessions_top_left{width: 49.8%;height: 100%;float: left;border-right: 0.05rem solid #FAFAFA;}
  .yf_Concessions_top_font{width: 4.95rem;height: 2.6rem;float: left;margin-top: 1.275rem;margin-left: 0.525rem;}
  .yf_Concessions_top_font p:first-of-type{font-size: 1rem;text-align: center;}
  .yf_Concessions_top_font p:last-of-type{font-size: 10%;text-align: center;}
  .yf_Concessions_top_img{width: 3.75rem;height: 3.3rem;float: right;margin-top: 0.875rem;margin-right: 0.525rem;}
  .yf_Concessions_top_img img{width: 100%;height: 100%;}
  .yf_Concessions_top_right{width: 49.8%;height: 100%;float: right;}
  .yf_Concessions_bottom{width: 100%;height: 49%;float: left;}

  .yf_Recommend{width: 100%;height: 2.2rem;float: left;border-bottom: 0.05rem solid #F9F9F9;margin-top: 0.725rem;}
  .yf_Recommend h2{color: #9BA0A5;line-height: 2.2rem;text-indent: 1.2rem;}
  .yf_first{width: 100%;height: 7.7rem;float: left;border-bottom: 0.025rem solid #EAEAEA;}
  .yf_first_img{width: 4.75rem;height: 4.8rem;float: left;margin-top: 0.825rem;margin-left: 0.425rem;}
  .yf_first_img img{width: 100%;height: 100%;}
  .yf_first_right{width: 13.275rem;height:6.3rem;float: right;margin-top: 0.825rem;}
  .yf_first_right_top{width: 100%;height: 3.425rem;float: left;border-bottom: 0.05rem dashed #EBEBEB;}
  .yf_first_right_top_top{width: 100%;height: 1.05rem;float: left;}
  .yf_first_right_top_top_img{width: 1.65rem;height: 1.05rem;float: left;background: #FFDC39;text-align: center;line-height: 1.05rem;}
  .yf_first_right_top_top span{margin-left: 0.675rem;}
  .yf_first_right_top_top_piao{width: 0.825rem;height: 0.875rem;float: right;border: 0.05rem solid #EFEFEF;border-radius: 3px;text-align: center;line-height: 0.675rem;margin-right: 0.575rem;margin-top: 0.045rem;}
  .yf_first_right_top_cen{width: 9.4rem;height: 0.75rem;float: left;margin-top: 0.125rem;}
  .yf_first_right_top_cen_img{width: 3rem;height: 0.75rem;float: left;}
  .yf_first_right_top_cen_img img{width: 100%;height: 100%;}
  .yf_first_right_top_cen span:first-of-type{color: #B86238;margin-left: 0.525rem;}
  .yf_first_right_top_cen span:last-of-type{margin-left: 0.525rem;}
  .yf_first_right_top_bot{width: 15.4rem;height: 0.75rem;float: left;margin-top: 0.206rem;}
  .yf_first_right_top_bot pan,pan,pan{margin-left: 0.025rem;}
  .yf_first_right_but{width: 100%;height: 2.875rem;float: left;margin-top: 0.75rem;}
  .yf_first_right_but_top{width: 100%;height: 50%;float: left;}
  .yf_first_right_but_top_p{width: 0.825rem;height: 0.875rem;float: left;border: 0.05rem solid #EFEFEF;border-radius: 3px;text-align: center;line-height: 0.675rem;margin-left: 0.575rem;margin-top: 0.145rem;color: #fff;background: #F1716D;}
  .yf_first_right_but_top span{margin-left: 1.275m;}
  .footer{
    width: 100%;
    position:fixed;
    bottom:0;
    left:0;
    background:#fff;
    overflow:hidden;
    border-top:1px solid #cecbce;
  }
  .footer ul li{
    float: left;
    width: 25%;
    height: 2.9rem;
    text-align: center;
  }
  .footer ul li img{
    width: 1rem;
    height: 1rem;
    float: left;
    margin: 0.6rem 1.95rem 0.195rem;
  }
  .footer ul li p{
    float: left;
    font-size: 0.5rem;
    color: #6b6d6b;
    margin-left: 1.7rem;
  }
</style>
