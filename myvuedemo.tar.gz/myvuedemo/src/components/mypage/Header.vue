<template>

  <div>
    <div class="yf_header">
          <div class="yf_header_top">
              <div class="yf_header_top_map_img">
                <img src="@/assets/img/wm1.jpg"/>
              </div>
              北京市大兴区天宫院
              <img src="@/assets/img/waimai2.jpg" style="margin-left: 0.325rem;"/>
          </div>
          <div class="yf_header_top_right">
              <div class="yf_header_top_right_p">36℃<br />高温
              <div class="yf_header_top_right_img"><img src="@/assets/img/wm3.gif"/></div></div>
          </div>
          <div class="yf_header_search">
              <input type="text" placeholder="搜索商家、商品名称" src="@/assets/img/wm4.gif"/>
          </div>
          <div class="yf_header_ul">
              <ul v-for='foodlink in foods'>
                <!--https://blog.csdn.net/mning199201/article/details/81355882-->
                  <li><a :href="foodlink.link">{{ foodlink.food }}</a></li>
              </ul>
          </div>
      </div>
  </div>
</template>

<script>
    export default {
        name: "Header",
        data(){
          return{
              foods:[
                {link:'a.com',food:'麻辣烫'},
                {link:'b.com',food:'汉堡包'},
                {link:'c.com',food:'西贝'},
                {link:'e.com',food:'玉米'},
                {link:'f.com',food:'我的菜'}
              ]
          }
        }
    }




</script>

<style scoped>
  body,ul,ol,li,dl,dt,dd,table,p,input,h1,h2,h3,h4,h5,h6{margin:0;padding:0;}
  body{font-size:0.025rem;font-family:Arial,"微软雅黑";}
  a:link,a:visited{text-decoration:none;outline:none;color:#5E5E5E;}
  a img{border:none;}
  ul,li{list-style:none;}
  a:hover{color:#1C468E;}
  input{vertical-align:middle;}



  body {
    font-family: "微软雅黑", "宋体", sans-serif;
  }

  li {
    list-style: none;
  }



  div{margin:0;padding:0;font-size:0.025rem;font-family:Arial,"微软雅黑";}
  .yf_header{width: 100%;height: 7.85rem;background: #2285F4;border: 0.025rem solid #84BBF9;border-left: none;border-right: none;}
  .yf_header_top{width: 11.525rem;height: 1.175rem;float: left;margin-top: 1.05rem;margin-left: 1.925rem;color: #fff;line-height: 1.175rem;text-indent: 1.2/
5m;}
  .yf_header_top_map_img{width: 0.8rem;height: 1.15rem;float: left;margin-left: 0.035rem;margin-top: 0.035rem;}
  .yf_header_top_map_img img{width: 100%;height: 100%;float: left;}
  .yf_header_top_right{width: 3.225rem;height: 2.075rem;float: right;margin-top: 1.125rem;margin-right: 1.575rem;}
  .yf_header_top_right_p{width: 3.625rem;height: 2.175rem;color: #fff;}
  .yf_header_top_right_img{width: 1.25rem;height: 2.275rem;float: right;margin-top: -0.955rem;}
  .yf_header_top_right_img img{width: 100%;height: 100%;}
  .yf_header_search{width:100%;height: 2.125rem;float: left;top: 10%;background: #2285F4;}
  .yf_header_search input{color: #9D9FA7;border: none;height: 1.725rem;width: 80%;margin-top: 0.225rem;margin-left: 10%;text-indent: 2.375rem;border-radius: 50px }
  .yf_header_ul{width: 100%;height: 1.035rem;float: left;margin-top: 0.675rem;}
  .yf_header_ul ul li a{width: 20%;height: 1.035rem;float: left;list-style: none;color: #fff;line-height: 1.035rem;text-align: center;text-indent: 0.375rem;}
  .yf_sort_div_top ul li{width: 24%;height: 4.863rem;float: left;}
  .yf_sort_div_top ul li img{width: 85%;height: 3.863rem;text-align: center;margin-left: 0.325rem;}
  .yf_sort_div_top ul li p{text-align: center;}
  .yf_banner img{width: 100%;height: 100%;}
  .yf_Concessions_top_font p:first-of-type{font-size: 1rem;text-align: center;}
  .yf_Concessions_top_font p:last-of-type{font-size: 10%;text-align: center;}
  .yf_Concessions_top_img img{width: 100%;height: 100%;}

  .yf_Recommend h2{color: #9BA0A5;line-height: 2.2rem;text-indent: 1.2rem;}
  .yf_first_img img{width: 100%;height: 100%;}
  .yf_first_right_top_top span{margin-left: 0.675rem;}
  .yf_first_right_top_cen_img img{width: 100%;height: 100%;}
  .yf_first_right_top_cen span:first-of-type{color: #B86238;margin-left: 0.525rem;}
  .yf_first_right_top_cen span:last-of-type{margin-left: 0.525rem;}
  .yf_first_right_top_bot pan,yang,fan{margin-left: 0.025rem;}
  .yf_first_right_but_top sa{margin-left: 1.275m;}

  .footer ul li{
    float: left;
    width: 25%;
    height: 2.9rem;
    text-align: center;
  }
  .footer ul li img{
    width: 1rem;
    height: 1rem;
    float: left;
    margin: 0.6rem 1.95rem 0.195rem;
  }
  .footer ul li p{
    float: left;
    font-size: 0.5rem;
    color: #6b6d6b;
    margin-left: 1.7rem;
  }
</style>
