<template>
    <div class="Title_div">
      <div class='container' id='header'>				<!--class='container'表示整体水平居中 -->
        <div class='col-xs-6 col-sm-6 col-md-6 col-lg-6 logo_png'>	<!--表示这个div在各个类型屏幕上都占6列（bootstrap分的）-->
          <img src='../../assets/img2/logo.png'>
        </div>
        <div class='col-xs-offset-2 col-xs-4 col-xs-offset-2 col-sm-4 col-xs-offset-2 col-xs-offset-2 col-md-4 col-xs-offset-2 col-xs-offset-2 col-xs-offset-2 col-lg-4'>		<!--表示这个div在各个类型屏幕上都空2列占4列（bootstrap分的，这是最完整的标准写法，下面还有简单写法-->
          <div class="input-group">
            <input type="text" class="form-control" placeholder="请输入搜索对象" aria-describedby="basic-addon2">
            <span class="input-group-btn">
						<button type="button" class="btn btn-warning">搜索</button>
					</span>
          </div>
        </div>
      </div>
    </div>
</template>

<script>
    export default {
        name: "Title_div"
    }
</script>

<style scoped>
  #header{						/*--这里的属性设置，可以从浏览器的Elements/styles下面复制出来，再进行修改--*/
    margin-top:30px;
    margin-bottom:30px;
  }
  .nav-pills>li.active>a, .nav-pills>li.active>a:focus, .nav-pills>li.active>a:hover {
    color: #fff;
    background-color: red;
    border-bottom:solid 3px green;
  }
  #carousel-example-generic img{
    width:100%;
  }
  .logo_png{
    text-align: left;
  }

</style>
