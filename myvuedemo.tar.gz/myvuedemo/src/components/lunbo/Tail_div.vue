<template>
    <div id="Tail_div">

      <div class='container'>
        <div class='col-xs-12'>
          <nav aria-label="...">
            <ul class="pager">
              <li class='pull-left'><a href="/">Previous</a></li>
              <li class='pull-right'><a href="#">Next</a></li>
            </ul>
          </nav>
        </div>
      </div>

      <div class='container'>
        <div class='col-xs-12'>
          <ol class="breadcrumb">
            <li class="active"><a href="#">Home</a></li>
            <li><a href="http://www.baidu.com">Library</a></li>
            <li><a href='#'>Data</a></li>
          </ol>
        </div>
      </div>
    </div>
</template>

<script>
    import HelloWorld from '../HelloWorld'

    export default {
        name: "Tail_div",
        components:{
          HelloWorld
        },
        data(){
          return{

          }
        }
    }



</script>


<style scoped>
    #Tail_div{
        text-align: left;
    }
</style>
