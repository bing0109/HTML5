import Vue from 'vue'
import Router from 'vue-router'
import HelloWorld from '@/components/HelloWorld'
//import Header from '@/components/mypage/Header.vue'
//import Nav from '../components/mypage/Nav.vue'
import MyDemoPage from '../components/MyDemoPage.vue'
import LunboPage from '../components/LunboPage.vue'
import ChuanCan from '../components/ChuanCan'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'HelloWorld',
      component: HelloWorld
    },
    {
      path:'/MyDemoPage',
      component: MyDemoPage
    },
    {
      path:'/LunboPage',
      component: LunboPage
    },
    {
      path:'/ChuanCan',
      component: ChuanCan
    }

  ]
})
