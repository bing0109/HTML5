// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
import Title_div from "./components/lunbo/Title_div";

import '../static/bootstrap3.3.7/dist/css/bootstrap.min.css'
import '../static/bootstrap3.3.7/dist/js/bootstrap.min.js'
import '../static/jquery.js'
Vue.config.productionTip = false

/*全局组件*/
Vue.component(Title_div)

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  components: { App },
  template: '<App/>'
})
